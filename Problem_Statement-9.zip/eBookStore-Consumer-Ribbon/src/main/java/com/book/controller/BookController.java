package com.book.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.book.domain.Book;

@RestController
//@RequestMapping("/book")
public class BookController {

	@Autowired
	@Qualifier("restTemplate")
	private RestTemplate restTemplate;
	
	
	@GetMapping("/getbyId/{bookId}")
	public Book getDetails(@PathVariable("bookId") Integer bookId) {
		Book book=restTemplate.getForObject("http://application/books/"+bookId,Book.class );
		return book;
	}
}
