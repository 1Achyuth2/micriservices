package com.book.domain;

public class Book {
	
	private Integer bookId;
	private String bookTitle;
	private String bookPublisher;
	private int bookYear;
	
	
	
public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
public Book(Integer bookId, String bookTitle, String bookPublisher, int bookYear) {
		super();
		this.bookId = bookId;
		this.bookTitle = bookTitle;
		this.bookPublisher = bookPublisher;
		this.bookYear = bookYear;
	}
@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookTitle=" + bookTitle + ", bookPublisher=" + bookPublisher
				+ ", bookYear=" + bookYear + "]";
	}

public Integer getBookId() {
	return bookId;
}
public void setBookId(Integer bookId) {
	this.bookId = bookId;
}
public String getBookTitle() {
	return bookTitle;
}
public void setBookTitle(String bookTitle) {
	this.bookTitle = bookTitle;
}
public String getBookPublisher() {
	return bookPublisher;
}
public void setBookPublisher(String bookPublisher) {
	this.bookPublisher = bookPublisher;
}
public int getBookYear() {
	return bookYear;
}
public void setBookYear(int bookYear) {
	this.bookYear = bookYear;
}



}
