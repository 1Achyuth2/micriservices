package com.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.book.domain.Book;
import com.book.proxy.BookServiceProxy;

@RestController
public class BookController {

	@Autowired
	private BookServiceProxy bookServiceProxy;
	
	@GetMapping(value="/shop/getbyId/{bookId}")
	public Book getById(@PathVariable("bookId") Integer bookId) {
		Book book= bookServiceProxy.getById(bookId);
		return book;
	}
	@GetMapping(value="/shop/get",produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Book> getBookDetails(){
   	 return bookServiceProxy.getDetails();
    }
}
