INSERT INTO bookdb.BookDetails( Book_Title,Book_Publisher,Book_Year) VALUES('English','ravi',2000);
INSERT INTO bookdb.BookDetails( Book_Title,Book_Publisher,Boo_kYear) VALUES('Telugu','hari',2001);
INSERT INTO bookdb.BookDetails( Book_Title,Book_Publisher,Book_Year) VALUES('Tamil','stephen',2002);
INSERT INTO bookdb.BookDetails( Book_Title,Book_Publisher,Book_Year) VALUES('Kannada','manoj',2003);