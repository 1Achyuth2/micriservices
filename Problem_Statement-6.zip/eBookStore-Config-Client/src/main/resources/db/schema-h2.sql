CREATE SCHEMA bookdb;

USE bookdb;

CREATE TABLE BookDetails(
Book_Id INT PRIMARY KEY AUTO_INCREMENT,
Book_Title VARCHAR(255),
Book_Publisher VARCHAR(255),
Book_Year INT
);